package Presentacion;

import java.io.*;
import java.util.*;

import Dominio.Empleado;
import Dominio.EmpleadoDiurno;
import Dominio.EmpleadoNocturno;

class excepcionUsuario extends Exception{
	
}

class excepcionPassword extends Exception{
	
}

public class Principal {
	static Scanner sc = new Scanner (System.in);
	static String tipo = null;
	
	public static void main(String[] args) throws IOException {
		//LEER TODOS los ficheros
		// leer empleados diurnos
		ArrayList <Empleado> empleadosdiurnos = new ArrayList<Empleado>();
		Empleado emp1 = new EmpleadoDiurno();
		empleadosdiurnos = emp1.leerEmpleados();
		
		// leer empleado nocturno
		
		ArrayList<Empleado> empleadosnocturnos = new ArrayList<Empleado>();
		Empleado emp2 = new EmpleadoNocturno();
		empleadosnocturnos = emp2.leerEmpleados();
		
		
		///////////////////
		
		Empleado emp = new EmpleadoNocturno();
		//login
		emp= login (emp, empleadosdiurnos, empleadosnocturnos);
		System.out.println("Login correcto.Bienvenido  " + emp.getNombreUsuario());
		System.out.println("Menu principal");
		System.out.println("1. Hacer pedido");
		System.out.println("2. Modificar producto");
		System.out.println("3. Cambiar contrase�a empelado");
		System.out.println("4. Log out");
	}
		public static Empleado login (Empleado emp, ArrayList<Empleado> empleadosdiurnos,ArrayList<Empleado> empleadosnocturnos) {
			boolean login = false;
			int usuario=0;
			String password="";
			boolean usuarioCorrecto = false;
			boolean passwordCorrecto = false;
			// bucle para la contrase�a y el usuario
			
			
			
		
			
			
			do {
				 boolean user = false;
				 do {
					 try {
						 System.out.println("indicame el usuario");
						 usuario = sc.nextInt();
						 user = true;
						 
						 
					 } catch (InputMismatchException e) {
						 System.out.println("no introduzcas letras");
						 sc.nextLine();
					 }
					 
				 } while (user == false);
				System.out.println("Contrase�a: ");	
				password = sc.next();
				//insercion de los campos 
				// lectura de diurnos
				for (int i = 0; i < empleadosdiurnos.size()+ empleadosnocturnos.size(); i++) {
					if (i < empleadosdiurnos.size()) {
						if (usuario == empleadosdiurnos.get(i).getCodigoAcceso()) {
							usuarioCorrecto = true;
							if( password.equals(empleadosdiurnos.get(i).getPassword())){ // da error
								passwordCorrecto=true;
								login = true;
								emp = empleadosdiurnos.get(i);
								tipo = "diurno";
								i = empleadosdiurnos.size()+empleadosnocturnos.size();
						}
					}
				} else {
					// comprobar empleados  nocturnos
					if (usuario == empleadosnocturnos.get(i - empleadosdiurnos.size()).getCodigoAcceso()) {
						usuarioCorrecto = true;
						if( password.equals(empleadosnocturnos.get(i - empleadosdiurnos.size()).getPassword())){
							passwordCorrecto = true;
							login = true;
							emp = empleadosnocturnos.get(i - empleadosdiurnos.size());
							tipo = "nocturno";
							i = empleadosdiurnos.size() + empleadosnocturnos.size();
							
						}
					}
				}
				
			}
				
				try {
					if (usuarioCorrecto == false)
						throw new excepcionUsuario();
					if (passwordCorrecto == false)
						throw new excepcionPassword();
				} catch (excepcionUsuario e) {
					System.err.println("111. Error. Loging incorrecto");
					sc.nextLine();
				} catch (excepcionPassword e) {
					System.err.println("222. Error. Password incorrecto");
					sc.nextLine();
				}
				
		}  while (login == false);
		
		return emp;
		
	
	
}
}

