package Dominio;
import java.util.*;

import Persistencia.EmpleadoNocturnoDao;

import java.io.FileNotFoundException;
import java.io.IOException;

public class EmpleadoNocturno extends Empleado {
private double plusproductividad;
private EmpleadoNocturnoDao empdao = new EmpleadoNocturnoDao();


public EmpleadoNocturno(int codigoAcceso, String nombreUsuario, String password, int nivel, String turno,
		double plusproductividad) {
	super(codigoAcceso, nombreUsuario, password, nivel, turno);
	this.plusproductividad = plusproductividad;
}

public EmpleadoNocturno() {
	
}

public double getPlusproductividad() {
	return plusproductividad;
}

public void setPlusproductividad(double plusproductividad) {
	this.plusproductividad = plusproductividad;
	
}
public ArrayList <Empleado> leerEmpleados () throws FileNotFoundException{
	return empdao.leerEmpleados();
	
}

public ArrayList <Empleado>escribirEmpleados(ArrayList <Empleado> empleados)throws IOException{
	return empdao.escribirEmpleados(empleados);
}


}


