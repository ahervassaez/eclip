package Dominio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Persistencia.ProductoPeDao;

public class ProductoPe extends Producto{
	private int dias;
	private ProductoPeDao proedao = new ProductoPeDao();
	
	
	public ProductoPe(int id, String nombre, double precio, int unidades, int dias) {
		super(id, nombre, precio, unidades);
		this.dias = dias;
	}

public ProductoPe() {
	
}

	public int getDias() {
		return dias;
	}



	public void setDias(int dias) {
		this.dias = dias;
	}


public ArrayList <Producto> leerProductos () throws FileNotFoundException{
	return proedao.leerProductos();
	
}

public ArrayList <Producto>escribirProductos(ArrayList <Producto> productos)throws IOException{
	return proedao.escribirProductos(productos);
	
}
}