package Dominio;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import Persistencia.EmpleadoDiurnoDao;
public class EmpleadoDiurno extends Empleado {
	private double retencion;
	private EmpleadoDiurnoDao empdao = new EmpleadoDiurnoDao();
	
	
	public EmpleadoDiurno(int codigoAcceso, String nombreUsuario, String password, int nivel, String turno,
			double retencion) {
		super(codigoAcceso, nombreUsuario, password, nivel, turno);
		this.retencion = retencion;
	
	}

	public EmpleadoDiurno() {
		
	}

	public double getRetencion() {
		return retencion;
	}


	public void setRetencion(double retencion) {
		this.retencion = retencion;
	}
	
	public ArrayList <Empleado> leerEmpleados () throws FileNotFoundException{
		return empdao.leerEmpleados();
		
	}
	
	public ArrayList <Empleado>escribirEmpleados(ArrayList <Empleado> empleados)throws IOException{
		return empdao.escribirEmpleados(empleados);
	}
	
	
}
