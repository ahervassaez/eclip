package Dominio;

public class ProductoNo extends Producto {
private Oferta oferta;


public ProductoNo(int id, String nombre, double precio, int unidades, Oferta oferta) {
	super(id, nombre, precio, unidades);
	this.oferta = oferta;
}

public ProductoNo () {
	
}
public Oferta getOferta() {
	return oferta;
}


public void setOferta(Oferta oferta) {
	this.oferta = oferta;
}


}
