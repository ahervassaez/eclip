package Persistencia;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Dominio.Empleado;
import Dominio.Oferta;
import Dominio.Producto;
import Dominio.ProductoPe;

 public class OfertaDao {
	public ArrayList <Oferta> leerofertas() throws FileNotFoundException{
		ArrayList <Oferta> Ofertas = new ArrayList <Oferta> ();
		Scanner out = new Scanner (new FileReader ("Oferta.txt"));
		out.next();
		int contador = out.nextInt();
		// leer productos
		for (int i = 0; i<contador;i++) {
			out.next();
			int id = out.nextInt();
			out.next();
			String tipo = out.next();
			if(tipo.equals("Porcentaje")) {
				out.next();
			}
			out.next();


		
			// guarda el empleado
			Oferta Ofe = new Oferta (id,tipo); 

			//incluyo en la lista
			Ofertas.add(Ofe);
		}
	return Ofertas;
	}
	
	
	public ArrayList <Oferta> escribirOfertas (ArrayList<Oferta> Ofertas) throws IOException {
		PrintWriter out = new PrintWriter (new FileWriter("Oferta.txt"));
		out.println("Ofertas ");
		out.println(Ofertas.size());
		for (int i=0;i<Ofertas.size(); i++) {
			out.println("Id: ");
			out.println(Ofertas.get(i).getId());
			out.println("nombre: ");
			out.println(Ofertas.get(i).getTipo());
		
		
	
			
		}
		out.close();
		return Ofertas;

}
 }
