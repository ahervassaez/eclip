package Persistencia;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Dominio.Empleado;
import Dominio.Producto;

abstract public class ProductoDao {
	public ProductoDao() {}

	abstract ArrayList <Producto> leerProductos() throws FileNotFoundException;
	abstract ArrayList <Producto>escribirProductos(ArrayList<Producto> productos ) throws FileNotFoundException, IOException; 
}
