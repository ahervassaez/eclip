package Persistencia;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Dominio.Oferta;
import Dominio.Producto;
import Dominio.ProductoNo;
import Dominio.ProductoPe;

public class ProductoNoDao extends ProductoDao{

	
	public ArrayList <Producto> leerProductos() throws FileNotFoundException{
		ArrayList <Producto> productosN = new ArrayList <Producto> ();
		OfertaDao ofedao = new OfertaDao();
		ArrayList <Oferta> ofertas=ofedao.leerofertas();
		Scanner out = new Scanner (new FileReader ("productoNo.txt"));
		out.next();
		int contador = out.nextInt();
		// leer productos
		for (int i = 0; i<contador;i++) {
			out.next();
			int id = out.nextInt();
			out.next();
			String nombre = out.next();
			out.next();
			double precio = out.nextDouble();
			out.next();
			int unidades = out.nextInt();
			out.next();
			int idOferta = out.nextInt();
			Oferta oferta=null;
			for(int j=0;j<ofertas.size();j++) {
				if(idOferta==ofertas.get(j).getId()) {
					oferta=ofertas.get(j);
				}
			}
			out.next();
			// guarda el empleado
			Producto proN = new ProductoNo (id,nombre,precio,unidades, oferta); 

			//incluyo en la lista
			productosN.add(proN);
		}
	return productosN;
	}
	
	
	public ArrayList <Producto> escribirProductos (ArrayList<Producto> productos) throws IOException {
		
	
		PrintWriter out = new PrintWriter (new FileWriter("productoPe.txt"));
		out.println("Productos perecederos: ");
		out.println(productos.size());
		for (int i=0;i<productos.size(); i++) {
			out.println("Id: ");
			out.println(productos.get(i).getId());
			out.println("nombre: ");
			out.println(productos.get(i).getNombre());
			out.println("precio: ");
			out.println(productos.get(i).getPrecio());
			out.println("unidades: ");
			out.println (productos.get(i).getUnidades());
			out.println("Oferta ");
			out.println (((ProductoNo)productos.get(i)).getOferta().getId());
		
	
			
		}
		out.close();
		return productos;
	}
}
