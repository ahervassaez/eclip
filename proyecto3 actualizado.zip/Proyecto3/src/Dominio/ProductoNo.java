package Dominio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Persistencia.ProductoNoDao;
import Persistencia.ProductoPeDao;

public class ProductoNo extends Producto {
private Oferta oferta;
private ProductoNoDao pronodao = new ProductoNoDao();


public ProductoNo(int id, String nombre, double precio, int unidades, Oferta oferta) {
	super(id, nombre, precio, unidades);
	this.oferta = oferta;
}

public ProductoNo () {
	
}
public Oferta getOferta() {
	return oferta;
}


public void setOferta(Oferta oferta) {
	this.oferta = oferta;
}

public ArrayList <Producto> leerProductos () throws IOException{
	return pronodao.leerProductos();
	
}

public void escribirProductos(ArrayList <Producto> productos)throws IOException{
	pronodao.escribirProductos(productos);
}

}
