package Persistencia;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


import Dominio.Producto;
import Dominio.ProductoPe;


public class ProductoPeDao extends ProductoDao {

	
	
	public ArrayList <Producto> leerProductos() throws FileNotFoundException{
		ArrayList <Producto> productos = new ArrayList <Producto> ();
		Scanner out = new Scanner (new FileReader ("productoPe.txt"));
		out.next();
		int contador = out.nextInt();
		// leer productos
		for (int i = 0; i<contador;i++) {
			out.next();
			int id = out.nextInt();
			out.next();
			String nombre = out.next();
			out.next();
			double precio = out.nextDouble();
			out.next();
			int unidades = out.nextInt();
			out.next();
			int dias = out.nextInt();
		
			// guarda el empleado
			Producto pro = new ProductoPe (id,nombre,precio,unidades,dias); 

			//incluyo en la lista
			productos.add(pro);
		}
	return productos;
	}
	
	
	public void  escribirProductos (ArrayList<Producto> productos) throws IOException {
		PrintWriter out = new PrintWriter (new FileWriter("productoPe.txt"));
		out.println("Productosperecederos: ");
		out.println(productos.size());
		for (int i=0;i<productos.size(); i++) {
			out.println("Id:");
			out.println(productos.get(i).getId());
			out.println("nombre:");
			out.println(productos.get(i).getNombre());
			out.println("precio:");
			String precio=productos.get(i).getPrecio() + " ";
			precio=precio.replace(".", ",");
			out.println(precio);
			out.println("unidades:");
			out.println (productos.get(i).getUnidades());
			out.println("dias:");
			out.println (((ProductoPe) productos.get(i)).getDias());
		
	
			
		}
		out.close();
		
	}
	
}
