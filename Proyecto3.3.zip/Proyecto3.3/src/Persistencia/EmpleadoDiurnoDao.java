package Persistencia;
import java.util.*;
import java.io.*;

import Dominio.Empleado;
import Dominio.EmpleadoDiurno;


public class EmpleadoDiurnoDao extends EmpleadoDao{
	
	public ArrayList <Empleado> leerEmpleados() throws FileNotFoundException{
		ArrayList <Empleado> empleados = new ArrayList <Empleado> ();
		Scanner out = new Scanner (new FileReader ("empleadosDiurno.txt"));
		out.next();
		int contador = out.nextInt();
		// leer empleados
		for (int i = 0; i<contador;i++) {
			out.next();
			int codigo = out.nextInt();
			out.next();
			String nombre = out.next();
			out.next();
			String password = out.next();
			out.next();
			int nivel = out.nextInt();
			out.next();
			String turno = out.next();
			out.next();
			double retencion = out.nextDouble();
			// guarda el empleado
			Empleado emp = new EmpleadoDiurno (codigo,nombre,password,nivel,turno,retencion); 
			
			//incluyo en la lista
			empleados.add(emp);
		}
	return empleados;
	}
	public ArrayList <Empleado> escribirEmpleados (ArrayList<Empleado> empleados) throws IOException {
		PrintWriter out = new PrintWriter (new FileWriter("empleadosDiurno.txt"));
		out.println("EmpleadosDiurno: ");
		out.println(empleados.size());
		for (int i=0;i<empleados.size(); i++) {
			out.println("C�digo: ");
			out.println(empleados.get(i).getCodigoAcceso());
			out.println("nombre: ");
			out.println(empleados.get(i).getNombreUsuario());
			out.println("Password: ");
			out.println(empleados.get(i).getPassword());
			out.println("nivel: ");
			out.println (empleados.get(i).getNivel());
			out.println("turno: ");
			out.println (empleados.get(i).getTurno());
			out.println("retencion: ");
			String retencion = ((EmpleadoDiurno)empleados.get(i)).getRetencion() + " ";
			retencion=retencion.replace(".",",");
			out.println(retencion);
			
		}
		out.close();
		return empleados;
	}


}
