package Persistencia;
import java.io.*;
import java.util.Scanner;

import Dominio.Empleado;
import Dominio.EmpleadoNocturno;

import java.util.*;


public class EmpleadoNocturnoDao extends EmpleadoDao {
	
public ArrayList <Empleado> leerEmpleados( ) throws FileNotFoundException{
	ArrayList <Empleado> empleados = new ArrayList <Empleado>();
	Scanner out = new Scanner (new FileReader ("empleadosNocturno.txt"));
	out.next();
	int contador = out.nextInt();
	//leer empleados
	for (int i = 0; i<contador;i++) {
		out.next();
		int codigo = out.nextInt();
		out.next();
		String nombre = out.next();
		out.next();
		String password = out.next();
		out.next();
		int nivel = out.nextInt();
		out.next();
		String turno = out.next();
		out.next();
		double plusproductividad = out.nextDouble();
		// se guarda empleado
		Empleado emp = new EmpleadoNocturno (codigo, nombre, password, nivel, turno, plusproductividad);
		// se incluye en la lista 
		empleados.add(emp);
	}
	return empleados;
}
	public ArrayList <Empleado> escribirEmpleados (ArrayList<Empleado> empleados) throws IOException{
		PrintWriter out = new PrintWriter (new FileWriter ("empleadosNocturno.txt"));
		out.println("EmpleadosNocturno: ");
		out.println(empleados.size());
		for (int i=0;i<empleados.size(); i++) {
			out.println("C�digo: ");
			out.println(empleados.get(i).getCodigoAcceso());
			out.println("nombre: ");
			out.println(empleados.get(i).getNombreUsuario());
			out.println("Password: ");
			out.println(empleados.get(i).getPassword());
			out.println("nivel: ");
			out.println (empleados.get(i).getNivel());
			out.println("turno: ");
			out.println (empleados.get(i).getTurno());
			out.println("plusproductividad: ");
			String plus = ((EmpleadoNocturno)empleados.get(i)).getPlusproductividad()+" ";
			plus = plus.replace(".",",");
			out.println(plus);
		}
		
		out.close();
		return empleados;
	}
}
