package Persistencia;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

import Dominio.Empleado;
import Dominio.Oferta;
import Dominio.Producto;
import Dominio.ProductoPe;

 public class OfertaDao {
	
	
	 public ArrayList<Oferta> leerOfertas() 
				throws FileNotFoundException {
			ArrayList <Oferta> ofertas = new ArrayList <Oferta>();
			Scanner in = new Scanner (new FileReader("ofertas.txt"));
			in.next();
			int contador = in.nextInt();
			//Leer ofertas
			for (int i=0; i<contador;i++) {
				in.next();
				int idOferta = in.nextInt();
				in.next();
				String tipo =in.next();
				Oferta ofe= new Oferta( tipo,idOferta);
				if(tipo.equals("porcentaje")) {
					in.next();
					int tantoPorciento= in.nextInt(); 
					in.next();
					int maximo= in.nextInt(); 
					ofe = new Oferta( tipo,idOferta,
							tantoPorciento,maximo);

				}
				//Guardo un oferta
				
				//incluyo en la lista
				ofertas.add(ofe);
			}
			
			return ofertas;
		}
		
		public ArrayList<Oferta> escribirOfertas(ArrayList<Oferta> ofertas) throws IOException {
			PrintWriter out = new PrintWriter (new FileWriter ("ofertas.txt"));
			out.println("Ofertas:");
			out.println(ofertas.size());
			for(int i=0;i<ofertas.size();i++) {
				out.println("idOferta:");
				out.println(ofertas.get(i).getIdOferta());
				out.println("Tipo:");
				out.println(ofertas.get(i).getTipo());	
				if(ofertas.get(i).getTipo().equals("porcentaje")) {
					out.println("tantoPorciento:");
					out.println(ofertas.get(i).getTantoPorCiento());
					out.println("maximo:");
					out.println(ofertas.get(i).getMaximo());	
				}
			}
			out.close();
			
			return ofertas;
			}
		
		
	
}
 
