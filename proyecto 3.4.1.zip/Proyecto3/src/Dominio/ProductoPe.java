package Dominio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Persistencia.ProductoPeDao;

public class ProductoPe extends Producto{
	private int dias;
	private ProductoPeDao proedao = new ProductoPeDao();
	
	
	public ProductoPe(int id, String nombre, double precio, int unidades, int dias) {
		super(id, nombre, precio, unidades);
		this.dias = dias;
	}

public ProductoPe() {
	
}

	public int getDias() {
		return dias;
	}



	public void setDias(int dias) {
		this.dias = dias;
	}

public Producto clone(){
	return new ProductoPe(this.getId(),this.getNombre(),this.getPrecio(), this.getUnidades(),this.getDias());
}

public Producto clone(int unidadesCompradas) {
	this.setUnidades(this.getUnidades()-unidadesCompradas);
	return new ProductoPe(this.getId(),this.getNombre(),this.getPrecio(), unidadesCompradas,this.getDias());
}
public double calcularOferta() {
	double precio=this.precio;
	if(this.getDias()==3) {
		precio =this.getUnidades() * this.getPrecio()*0.5;
	}
	if(this.getDias()==2) {
		precio =this.getUnidades() * this.getPrecio()*0.33;
	}
	if(this.getDias()==1) {
		precio =this.getUnidades() * this.getPrecio()*0.25;
	}
	return precio;
	
}
public ArrayList <Producto> leerProductos () throws IOException{
	return proedao.leerProductos();
	
}

public void escribirProductos(ArrayList <Producto> productos)throws IOException{
	proedao.escribirProductos(productos);
}
}
