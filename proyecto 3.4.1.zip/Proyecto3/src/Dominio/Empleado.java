package Dominio;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
abstract public class Empleado {
	private int CodigoAcceso;
	private String NombreUsuario;
	private String password;
	private int nivel;
	private String turno;
	
	public Empleado(int codigoAcceso, String nombreUsuario, String password, int nivel, String turno) {

		CodigoAcceso = codigoAcceso;
		NombreUsuario = nombreUsuario;
		this.password = password;
		this.nivel = nivel;
		this.turno = turno;
	}
	public Empleado() {
       
	}

	public int getCodigoAcceso() {
		return CodigoAcceso;
	}

	public void setCodigoAcceso(int codigoAcceso) {
		CodigoAcceso = codigoAcceso;
	}

	public String getNombreUsuario() {
		return NombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		NombreUsuario = nombreUsuario;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public String getTurno() {
		return turno;
	}

	public void setTurno(String turno) {
		this.turno = turno;
	}
	
	 abstract public double calcularProd();
	
	abstract public ArrayList <Empleado> leerEmpleados() throws FileNotFoundException;
	abstract public ArrayList <Empleado> escribirEmpleados (ArrayList <Empleado> empleados) throws IOException;
}// fin de Empleado
