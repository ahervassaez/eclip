package Persistencia;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Dominio.Empleado;
import Dominio.Producto;

abstract public class ProductoDao {
	public ProductoDao() {}

	abstract public ArrayList <Producto> leerProductos() throws FileNotFoundException, IOException;
	abstract public void escribirProductos(ArrayList<Producto> productos ) throws FileNotFoundException, IOException; 
}
