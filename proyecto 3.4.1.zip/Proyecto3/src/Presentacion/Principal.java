package Presentacion;

import java.io.*;
import java.util.*;

import javax.imageio.IIOException;

import Dominio.Empleado;
import Dominio.EmpleadoDiurno;
import Dominio.EmpleadoNocturno;
import Dominio.Producto;
import Dominio.ProductoNo;
import Dominio.ProductoPe;

class excepcionUsuario extends Exception {

}

class excepcionPassword extends Exception {

}

class excepcionCodigof extends Exception {
	
}
class excepcionCodigoR extends Exception {
	
}
class excepcionNoproducto extends Exception {
	
}
class excepcionnumneg extends Exception {
	
}

public class Principal {
	static Scanner sc = new Scanner(System.in);
	static String tipo = null;

	public static void main(String[] args) throws IOException, Exception {
		// LEER TODOS los ficheros
		// leer empleados diurnos
		ArrayList<Empleado> empleadosdiurnos = new ArrayList<Empleado>();
		Empleado emp1 = new EmpleadoDiurno();
		empleadosdiurnos = emp1.leerEmpleados();

		// leer empleado nocturno

		ArrayList<Empleado> empleadosnocturnos = new ArrayList<Empleado>();
		Empleado emp2 = new EmpleadoNocturno();
		empleadosnocturnos = emp2.leerEmpleados();

		// leer productos perecederos

		ArrayList<Producto> prope = new ArrayList<Producto>();
		Producto pro1 = new ProductoPe();
		prope = pro1.leerProductos();

		// ler productos no perecederos

		ArrayList<Producto> pronope = new ArrayList<Producto>();
		Producto pro2 = new ProductoNo();
		pronope = pro2.leerProductos();

		// Creamos carrito
		ArrayList<Producto> carro = new ArrayList<Producto>();
		///////////////////
		Producto Pro = new ProductoNo();

		Empleado emp = new EmpleadoNocturno();

		emp = login(emp, empleadosdiurnos, empleadosnocturnos);

		System.out.println("Login correcto.Bienvenido  " + emp.getNombreUsuario());
		boolean salir = false;
		while (!salir) {// login
			System.out.println("Menu principal");
			System.out.println("1. Hacer pedido");
			System.out.println("2. Modificar producto");
			System.out.println("3. Cambiar contrase�a empelado");
			System.out.println("4. Log out");

			// switch para acceder al men� principal

			try {
				switch (sc.nextInt()) {

				case 1:
					boolean salir1 = false;
					while (!salir1) {
						System.out.println("1.1 A�adir un tipo de producto ");
						System.out.println("1.2 Visualizar precio total");
						System.out.println("1.3 Imprimir factura");
						System.out.println("1.4 Terminar pedido");
						// switch para el submenu

						switch (sc.nextInt()) {
						case 1:
							System.out.println("estos son los productos de los que disponemos: ");
							// falta seleccionar opcion y acceder a los productos
							// Mostar productos
							System.out.println("perecederos: ");
							for (int i = 0; i < prope.size(); i++) {
								System.out.println(prope.get(i).getId() + " " + prope.get(i).getNombre() + " "
										+ prope.get(i).getPrecio() + " " + prope.get(i).getUnidades() + " "
										+ ((ProductoPe) prope.get(i)).getDias());

							}
							System.out.println("No perecederos:");
							for (int i = 0; i < pronope.size(); i++) {
								System.out.println(pronope.get(i).getId() + " " + pronope.get(i).getNombre() + " "
										+ pronope.get(i).getPrecio() + " " + pronope.get(i).getUnidades() + " "
										+ ((ProductoNo) pronope.get(i)).getOferta().getTipo());

							}

							A�adirP(prope, pronope, carro);

							break;
						case 2:
							System.out.println("1.2 Visualizar precio total");
							PrecioTotal(pronope, prope, carro);
							break;
						case 3:
							System.out.println("1.3 Imprimir factura");
							
							Factura (prope, pronope, carro, emp);
							
							break;
						case 4:
							System.out.println("1.4 Terminar pedido");
							salir1 = true;

							break;

						default:
							System.err.println("Solo se permiten n�meros del 1 al 4");
						}
					}

					break;

				case 2:
					System.out.println("estos son los productos de los que disponemos: ");
					// falta seleccionar opcion y acceder a los productos
					// Mostar productos
					System.out.println("perecederos: ");
					for (int i = 0; i < prope.size(); i++) {
						System.out.println(prope.get(i).getId() + " " + prope.get(i).getNombre() + " "
								+ prope.get(i).getPrecio() + " " + prope.get(i).getUnidades() + " "
								+ ((ProductoPe) prope.get(i)).getDias());

					}
					System.out.println("No perecederos:");
					for (int i = 0; i < pronope.size(); i++) {
						System.out.println(pronope.get(i).getId() + " " + pronope.get(i).getNombre() + " "
								+ pronope.get(i).getPrecio() + " " + pronope.get(i).getUnidades() + " "
								+ ((ProductoNo) pronope.get(i)).getOferta().getTipo());

					}

					System.out.println("�que desea modificar? Introduzca el c�digo del producto: ");

					// hay que comprobar las listas de los productos

					System.out.println("2.1 Modificar nombre ");
					System.out.println("2.2 Modificar precio ");
					System.out.println("2.3 Modificar c�digo ");
					System.out.println("2.4 Modificar n�mero de unidades ");
					System.out.println("2.5 Salir a menu principal");
					// switch para submenu 2
					boolean salir2 = false;

					while (!salir2) {
						switch (sc.nextInt()) {
						case 1:
							ModificarN(pro1, prope, pronope);
							break;
						case 2:
							ModificarP(pro1, prope, pronope);
							break;

						case 3:
							ModificarC(pro1, prope, pronope);
							break;

						case 4:
							ModificarU(pro1, prope, pronope);
							break;
						case 5:
							salir2 = true;
							break;
						default:
							System.out.println("solo se permiten n�meros del 1 al 5");
						}
					}
					break;

				case 3:
					cambiar(emp, empleadosdiurnos, empleadosnocturnos);
					break;

				case 4:
					System.out.println("log out");
					System.exit(0);
					break;

				default:
					System.err.println("solo se permiten n�meros del 1 al 4");

				}
			} catch (InputMismatchException e) {
				System.err.println("solo n�meros del 1 al 4");
				sc.next();
			}
		}

		/////////////////////////////////////////////

		/*
		  prueba para leer empleados diurnos y nocturnos
		  
		  System.out.println("Empleados diurnos: "); for(int i = 0; i<
		  empleadosdiurnos.size();i++) { System.out.println(
		  empleadosdiurnos.get(i).getNombreUsuario() + " " +
		  empleadosdiurnos.get(i).getTurno() + " " +
		 empleadosdiurnos.get(i).getNivel());
		  
		  }
		  
		  System.out.println("Empleados nocturnos: "); for(int i = 0; i<
		  empleadosnocturnos.size(); i++) {
		  
		  System.out.println(empleadosnocturnos.get(i).getNombreUsuario() + " " +
		 empleadosnocturnos.get(i).getTurno() + " " +
		  empleadosnocturnos.get(i).getNivel());
		  
		  }
		  
		 */

	}

	public static Empleado login(Empleado emp, ArrayList<Empleado> empleadosdiurnos,
			ArrayList<Empleado> empleadosnocturnos) {
		boolean login = false;
		int usuario = 0;
		String password = "";
		boolean usuarioCorrecto = false;
		boolean passwordCorrecto = false;

		// bucle para la contrase�a y el usuario

		do {
			boolean user = false;
			do {
				try {
					System.out.println("indicame el usuario");
					usuario = sc.nextInt();
					user = true;

				} catch (InputMismatchException e) {
					System.out.println("no introduzcas letras");
					sc.nextLine();
				}

			} while (user == false);
			System.out.println("Contrase�a: ");
			password = sc.next();
			// insercion de los campos
			// lectura de diurnos
			for (int i = 0; i < empleadosdiurnos.size() + empleadosnocturnos.size(); i++) {
				if (i < empleadosdiurnos.size()) {
					if (usuario == empleadosdiurnos.get(i).getCodigoAcceso()) {
						usuarioCorrecto = true;
						if (password.equals(empleadosdiurnos.get(i).getPassword())) { // da error
							passwordCorrecto = true;
							login = true;
							emp = empleadosdiurnos.get(i);
							tipo = "diurno";
							i = empleadosdiurnos.size() + empleadosnocturnos.size();
						}
					}
				} else {
					// comprobar empleados nocturnos
					if (usuario == empleadosnocturnos.get(i - empleadosdiurnos.size()).getCodigoAcceso()) {
						usuarioCorrecto = true;
						if (password.equals(empleadosnocturnos.get(i - empleadosdiurnos.size()).getPassword())) {
							passwordCorrecto = true;
							login = true;
							emp = empleadosnocturnos.get(i - empleadosdiurnos.size());
							tipo = "nocturno";
							i = empleadosdiurnos.size() + empleadosnocturnos.size();

						}
					}
				}

			}

			try {
				if (usuarioCorrecto == false)
					throw new excepcionUsuario();
				if (passwordCorrecto == false)
					throw new excepcionPassword();
			} catch (excepcionUsuario e) {
				System.err.println("111. Error. Loging incorrecto");
				sc.nextLine();
			} catch (excepcionPassword e) {
				System.err.println("222. Error. Password incorrecto");
				sc.nextLine();
			}

		} while (login == false);

		return emp;

	}// fin de metodo login

	public static Empleado cambiar(Empleado emp, ArrayList<Empleado> empleadosdiurnos,
			ArrayList<Empleado> empleadosnocturnos) throws IOException {

		boolean correcto = true;

		for (int i = 0; i < empleadosdiurnos.size() + empleadosnocturnos.size(); i++) { // recorrer las dos listas de
																						// empleados
			// emoleados diurnos
			if (i < empleadosdiurnos.size()) {
												
				// contenido
				do {
					correcto = true;
					// recorrer empleado diurno

					if (emp.getCodigoAcceso() == empleadosdiurnos.get(i).getCodigoAcceso()) {
						System.out.println("Inserte nueva contrase�a");
						String Contrase�a = sc.next();
						// para comparar el codigo
						if (Contrase�a.equals(empleadosdiurnos.get(i).getPassword())) {
							System.err.println("Ha puesto su contrase�a actual");
							correcto = false;
							// Si el codigo nuevo es repetido da fallo y se repite

						}
						if (correcto == true) {

							empleadosdiurnos.get(i).setPassword(Contrase�a);
							empleadosdiurnos.get(i).escribirEmpleados(empleadosdiurnos);
							System.out.println("contrase�a cambiada");
							// Guarda el contrase�a nuevo

						}
					}

				} while (correcto == false);

				// empleados nocturnos de momento no accede al txt
			} else {
				if (emp.getCodigoAcceso() == empleadosnocturnos.get(i - empleadosdiurnos.size()).getCodigoAcceso()) {
					// contenido

					do {
						correcto = true;
						// En caso de fallo que vuelva a repetir
						System.out.println("Inserte nueva contrase�a");

						String Contrase�a = sc.next();

						if (emp.getCodigoAcceso() == empleadosnocturnos.get(i - empleadosdiurnos.size())
								.getCodigoAcceso()) {
							// para comparar el codigo
							if (Contrase�a.equals(empleadosnocturnos.get(i - empleadosdiurnos.size()).getPassword())) {
								System.err.println("Ha puesto la contrase�a actual");
								correcto = false;
								// Si el codigo nuevo es repetido da fallo y se repite

							}
							if (correcto == true) {

								empleadosnocturnos.get(i - empleadosdiurnos.size()).setPassword(Contrase�a);
								empleadosnocturnos.get(i - empleadosdiurnos.size())
										.escribirEmpleados(empleadosnocturnos);
								System.out.println("contrase�a cambiada");
								// Guarda el contrase�a nuevo

							}
						}

					} while (correcto == false);
				}

			}
		}

		return emp;
	}

	public static Producto ModificarN(Producto pro, ArrayList<Producto> prope, ArrayList<Producto> pronope)
			throws IOException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Codigo producto: ");
		int Codigo_Producto = sc.nextInt();

		boolean correcto = true;

		for (int i = 0; i < prope.size() + pronope.size(); i++) { // recorrer las dos listas de objetos

			if (i < prope.size()) {

				do {
					correcto = true;

					if (Codigo_Producto == prope.get(i).getId()) {
						System.out.println("Inserte nueva Nombre");
						String nombre = sc.next();
						// para comparar el codigo
						if (nombre.equals(prope.get(i).getNombre())) {
							System.err.println("Inserte un nombre diferente");
							correcto = false;

						}
						for (int j = 0; j < prope.size() + pronope.size(); j++) {
							if (j < prope.size()) {

								if (nombre.equals(prope.get(j).getNombre())) {
									System.err.println("Inserte un nombre diferente");
									correcto = false;
								}
							} else {
								if (nombre.equals(pronope.get(j - prope.size()).getNombre())) {
									System.err.println("Inserte un nombre diferente");
									correcto = false;
								}

							}

						}
						if (correcto == true) {

							prope.get(i).setNombre(nombre);
							prope.get(i).escribirProductos(prope);
							System.out.println("Nombre cambiado");
							// Guarda el nombre nuevo

						}
					}

				} while (correcto == false);
			} else {
				if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {

					do {
						correcto = true;
						System.out.println("Inserte nuevo nombre");

						String nombre = sc.next();

						if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {
							// para comparar el codigo
							if (nombre.equals(pronope.get(i - prope.size()).getNombre())) {
								System.err.println("Ha puesto el nombre actual");
								correcto = false;
							}
							for (int j = 0; j < prope.size() + pronope.size(); j++) {
								if (j < prope.size()) {
									if (nombre == prope.get(j).getNombre()) {
										System.err.println("Inserte un nombre diferente");
										correcto = false;
									}
								} else {
									if (nombre == pronope.get(j - prope.size()).getNombre()) {
										System.err.println("Inserte un nombre diferente");
										correcto = false;
									}

								}
							}
							if (correcto == true) {

								pronope.get(i - prope.size()).setNombre(nombre);
								pronope.get(i - prope.size()).escribirProductos(pronope);
								System.out.println("Nombre cambiado");
								// Guarda el nombre nuevo

							}
						}

					} while (correcto == false);
				}

			}

		}
		return pro;

	}

	public static Producto ModificarP(Producto pro, ArrayList<Producto> prope, ArrayList<Producto> pronope)
			throws IOException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Codigo producto: ");
		int Codigo_Producto = sc.nextInt();

		boolean correcto = true;

		for (int i = 0; i < prope.size() + pronope.size(); i++) {

			if (i < prope.size()) {

				do {
					correcto = true;

					if (Codigo_Producto == prope.get(i).getId()) {
						System.out.println("Inserte nuevo Precio");
						double precio = sc.nextDouble();
						if (precio <= 0) {
							correcto = false;

						}
						if (precio == prope.get(i).getPrecio()) {
							System.err.println("Inserte un nombre diferente");
							correcto = false;

						}
						if (correcto == true) {

							prope.get(i).setPrecio(precio);
							prope.get(i).escribirProductos(prope);
							System.out.println("Precio cambiado");

						}
					}

				} while (correcto == false);
			} else {
				if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {

					do {
						correcto = true;
						System.out.println("Inserte nuevo Precio");

						double precio = sc.nextDouble();
						if (precio <= 0) {
							correcto = false;

						}

						if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {

							if (precio == pronope.get(i - prope.size()).getPrecio()) {
								System.err.println("Ha puesto el precio actual");
								correcto = false;

							}
							if (correcto == true) {

								pronope.get(i - prope.size()).setPrecio(precio);
								pronope.get(i - prope.size()).escribirProductos(pronope);
								System.out.println("Precio cambiado");

							}
						}

					} while (correcto == false);
				}

			}

		}
		return pro;

	}

	public static Producto ModificarC(Producto pro, ArrayList<Producto> prope, ArrayList<Producto> pronope)
			throws IOException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Codigo producto: ");
		int Codigo_Producto = sc.nextInt();

		boolean correcto = true;

		for (int i = 0; i < prope.size() + pronope.size(); i++) {

			if (i < prope.size()) {

				do {
					correcto = true;

					if (Codigo_Producto == prope.get(i).getId()) {
						System.out.println("Inserte nuevo codigo");
						int codigo = sc.nextInt();
						if (codigo == prope.get(i).getId()) {
							System.err.println("Inserte un codigo diferente");
							correcto = false;

						}
						for (int j = 0; j < prope.size() + pronope.size(); j++) {
							if (j < prope.size()) {
								if (Codigo_Producto == prope.get(j).getId()) {
									System.err.println("Inserte un codigo diferente");
									correcto = false;
								}
							} else {
								if (Codigo_Producto == pronope.get(j - prope.size()).getId()) {
									System.err.println("Inserte un codigo diferente");
									correcto = false;
								}

							}
						}
						if (correcto == true) {

							prope.get(i).setId(codigo);
							prope.get(i).escribirProductos(prope);
							System.out.println("Codigo cambiado");

						}
					}

				} while (correcto == false);
			} else {
				if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {

					do {
						correcto = true;
						System.out.println("Inserte nuevo Codigo");

						int codigo = sc.nextInt();

						if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {

							if (codigo == pronope.get(i - prope.size()).getPrecio()) {
								System.err.println("Ha puesto el precio actual");
								correcto = false;

							}
							for (int j = 0; j < prope.size() + pronope.size(); j++) {
								if (j < prope.size()) {
									if (Codigo_Producto == prope.get(j).getId()) {
										System.err.println("Inserte un codigo diferente");
										correcto = false;
									}
								} else {
									if (Codigo_Producto == pronope.get(j - prope.size()).getId()) {
										System.err.println("Inserte un codigo diferente");
										correcto = false;
									}

								}
							}

						}
						if (correcto == true) {

							pronope.get(i - prope.size()).setId(codigo);
							pronope.get(i - prope.size()).escribirProductos(pronope);
							System.out.println("Codigo cambiado");

						}

					} while (correcto == false);
				}

			}

		}
		return pro;

	}

	public static Producto ModificarU(Producto pro, ArrayList<Producto> prope, ArrayList<Producto> pronope)
			throws IOException {
		boolean correcto = true;

		for (int i = 0; i < prope.size() + pronope.size(); i++) {

			Scanner sc = new Scanner(System.in);
			System.out.println("Codigo producto: ");
			int Codigo_Producto = sc.nextInt();

			if (i < prope.size()) {

				do {
					correcto = true;

					if (Codigo_Producto == prope.get(i).getId()) {
						System.out.println("Inserte Cantidad de unidades");
						int unidades = sc.nextInt();
						if (unidades == prope.get(i).getUnidades()) {
							System.err.println("Inserte una  Cantidad de unidades diferente");
							correcto = false;

						}
						if (correcto == true) {

							prope.get(i).setUnidades(unidades);
							prope.get(i).escribirProductos(prope);
							System.out.println("Unidades cambiadas");

						}
					}

				} while (correcto == false);

			} else {
				if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {

					do {
						correcto = true;
						System.out.println("Inserte nueva cantidad de unidades");

						int unidades = sc.nextInt();

						if (Codigo_Producto == pronope.get(i - prope.size()).getId()) {

							if (unidades == pronope.get(i - prope.size()).getUnidades()) {
								System.err.println("Ha puesto las unidades  actuales");
								correcto = false;

							}
							if (correcto == true) {

								pronope.get(i - prope.size()).setUnidades(unidades);
								pronope.get(i - prope.size()).escribirProductos(pronope);
								System.out.println("unidades cambiadas cambiado");

							}
						}

					} while (correcto == false);
				}

			}

		}
		return pro;

	}// fin de modificarU

	public static void A�adirP(ArrayList<Producto> prope, ArrayList<Producto> pronope, ArrayList<Producto> carro)
			throws IOException, excepcionCodigoR {

		try {
			boolean correcto = true;
			boolean codigoCorrecto = false;
			boolean codigoRepetido = false;
			boolean noProducto = false;
			do {// recorremos las dos arrays para ver que codigo se pide

				System.out.println("introduzca el c�digo para agregar al carrito:");
				Scanner sc = new Scanner(System.in);
				int Codigo = sc.nextInt();

				for (int i = 0; i < prope.size() + pronope.size(); i++) {

					if (i < prope.size()) {

						correcto = true;

						// productos perecederos
						if (Codigo == prope.get(i).getId()) {
							codigoCorrecto = true;
							System.out.println("Inserte Cantidad de unidades");
							int unidades = sc.nextInt();
							// si el usuario inserta n�meros negativos o igual que 0
							if (unidades <= 0)
								throw new excepcionnumneg();
							if (unidades > prope.get(i).getUnidades()) {
								noProducto = true;
								correcto = false;

							}
							if (correcto == true) {

								// recorrer carro
								for (int j = 0; j < carro.size(); j++) {

									if (Codigo == carro.get(j).getId()) {

										correcto = false;

									}
								}
								if (correcto == true) {

									for (int k = 0; k < prope.size(); k++) {

										if (Codigo == prope.get(k).getId()) {

											carro.add(prope.get(k).clone(unidades));
											prope.get(k).escribirProductos(prope);
											System.out.println("Producto a�adido ");

											// for para comprobar el carro

											System.out.println("esto es lo que tiene en el pedido: ");
											for (int l = 0; l < carro.size(); l++) {
												System.out.println("cod: " + carro.get(l).getId() + "unidades "
														+ carro.get(l).getUnidades() + "nombre: "
														+ carro.get(l).getNombre());
													

											}
										}
									}
								} else {
									codigoRepetido = true;
								}

							}
						}

						// lista de productos no perecederos
					}
					if (i < pronope.size()) {

						correcto = true;

						// productos perecederos
						if (Codigo == pronope.get(i).getId()) {
							codigoCorrecto = true;
							System.out.println("Inserte Cantidad de unidades");
							int unidades = sc.nextInt();
							if (unidades <= 0)
								throw new excepcionnumneg();
							if (unidades > pronope.get(i).getUnidades()) {
								noProducto = true;
								correcto = false;

							}
							if (correcto == true) {

								// recorrer carro
								for (int j = 0; j < carro.size(); j++) {

									if (Codigo == carro.get(j).getId()) {

										correcto = false;

									}
								}
								if (correcto == true) {

									for (int k = 0; k < pronope.size(); k++) {

										if (Codigo == pronope.get(k).getId()) {

											carro.add(pronope.get(k).clone(unidades));
											pronope.get(k).escribirProductos(pronope);
											System.out.println("Producto a�adido ");

											// for para comprobar el carro

											System.out.println("esto es lo que tiene en el pedido: ");
											for (int l = 0; l < carro.size(); l++) {
												System.out.println("cod: " + carro.get(l).getId() + "unidades "
														+ carro.get(l).getUnidades() + "nombre: "
														+ carro.get(l).getNombre());

											}

										}

									}

								} else {
									codigoRepetido = true;

								}

							}
						}

					}
				}

				if (codigoCorrecto == false)
					throw new excepcionCodigof();
				if (codigoRepetido == true)
					throw new excepcionCodigoR();
				if (noProducto == true)
					throw new excepcionNoproducto();

			} while (correcto == false);

		} catch (excepcionCodigof e1) {
			System.err.println(" Error. No existe ese c�digo ");
			sc.nextLine();
		} catch (excepcionCodigoR e2) {
			System.err.println(" Error. C�digo repetido ");
			sc.nextLine();
		} catch (excepcionNoproducto e3) {
			System.err.println("333. Error. N�mero insuficiente de productos disponibles");
			sc.nextLine();
		} catch (excepcionnumneg e4) {
			System.err.println(" Error. No se pueden poner numeros negativos o igual que 0");
			sc.nextLine();

		}
	}

	public static void PrecioTotal(ArrayList<Producto> prope, ArrayList<Producto> pronope, ArrayList<Producto> carro)
			throws IOException {
		double precio = 0;

		for (int i = 0; i < carro.size(); i++) {
			precio += carro.get(i).calcularOferta();

		}
		System.out.println("Precio total: " + precio);
	
		
	
		}

	
	
	public static void Factura(ArrayList<Producto> prope, ArrayList<Producto> pronope, ArrayList<Producto> carro, Empleado emp ) {
		
		System.out.println("Le ha atendido: " + emp.getNombreUsuario());
		
		
		
		for (int l = 0; l < carro.size(); l++) {
			System.out.println(" cod: " + carro.get(l).getId() + " unidades " + carro.get(l).getUnidades() + "nombre: "
					+ carro.get(l).getNombre()	+ " precio total: " + carro.get(l).getPrecio());
				
		}

		
		
	}
}// fin de clase principal
