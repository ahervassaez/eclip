package Dominio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Persistencia.ProductoNoDao;
import Persistencia.ProductoPeDao;

public class ProductoNo extends Producto {
private Oferta oferta;
private ProductoNoDao pronodao = new ProductoNoDao();


public ProductoNo(int id, String nombre, double precio, int unidades, Oferta oferta) {
	super(id, nombre, precio, unidades);
	this.oferta = oferta;
}

public ProductoNo () {
	
}
public Oferta getOferta() {
	return oferta;
}


public void setOferta(Oferta oferta) {
	this.oferta = oferta;
}

public Producto clone() {
	return new ProductoNo(this.getId(), 
			this.getNombre(), this.getPrecio(), this.getUnidades(), this.getOferta());
	}
	public Producto clone(int unidadesCompradas) {
		//se restan unidades compradas al objeto de la lista
		this.setUnidades(this.getUnidades()-unidadesCompradas);
		
		
		return new ProductoNo(this.getId(), this.getNombre(), this.getPrecio(),unidadesCompradas, this.getOferta());
		
		
	}
	public double calcularOferta() {
        double  Precio=this.getPrecio();
        int unidades= this.getUnidades();
        double resultado=0;
        if(this.getOferta().getTipo().equals("2x1")) {

        resultado=Precio*(unidades/2)+(Precio*(unidades%2));
        this.setPrecio(resultado);
        }



        if(this.getOferta().getTipo().equals("3x2")){
        {resultado=Precio*(unidades/3)*2+(Precio*(unidades%3));
        this.setPrecio(resultado);}
        }
        if(this.getOferta().getTipo().equals("porcentaje")) 
            this.getOferta().getTantoPorCiento();


        return resultado;
        }
	
		
	


public ArrayList <Producto> leerProductos () throws IOException{
	return pronodao.leerProductos();
	
}

public void escribirProductos(ArrayList <Producto> productos)throws IOException{
	pronodao.escribirProductos(productos);
}

}
