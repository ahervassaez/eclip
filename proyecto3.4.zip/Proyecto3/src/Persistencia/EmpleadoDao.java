package Persistencia;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import Dominio.Empleado;
abstract public class EmpleadoDao {
public EmpleadoDao() {
	
}
abstract ArrayList <Empleado> leerEmpleados() throws FileNotFoundException;
abstract ArrayList <Empleado>escribirEmpleados (ArrayList<Empleado> empleados ) throws FileNotFoundException, IOException; 
}
