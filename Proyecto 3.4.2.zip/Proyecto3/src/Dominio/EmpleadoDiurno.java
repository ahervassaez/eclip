package Dominio;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

import Persistencia.EmpleadoDiurnoDao;
public class EmpleadoDiurno extends Empleado {
	private double retencion;
	private EmpleadoDiurnoDao empdao = new EmpleadoDiurnoDao();
	
	
	public EmpleadoDiurno(int codigoAcceso, String nombreUsuario, String password, int nivel, String turno,
			double retencion) {
		super(codigoAcceso, nombreUsuario, password, nivel, turno);
		this.retencion = retencion;
	
	}

	public EmpleadoDiurno() {
		
	}

	public double getRetencion() {
		return retencion;
	}


	public void setRetencion(double retencion) {
		this.retencion = retencion;
	}
	
	public ArrayList <Empleado> leerEmpleados () throws FileNotFoundException{
		return empdao.leerEmpleados();
		
	}
	
	public ArrayList <Empleado>escribirEmpleados(ArrayList <Empleado> empleados)throws IOException{
		return empdao.escribirEmpleados(empleados);
	}

	
	public void calcularProd(  double precioT) {
		double productividad = 0;
	
		
	
			
				int nivel = this.getNivel();
		
		if (nivel == 1) {
			productividad += 1;
			
			
		} else if(nivel ==2 ) {
			productividad += 2- (2* ((EmpleadoDiurno)this).getRetencion()/100);
			if (precioT >= 200) {
				productividad =2;
			}
			
			
			
		} else {
			productividad += 3- (3* ((EmpleadoDiurno)this).getRetencion()/100);
		}
		
		
		this.setProductividad(productividad);
	}




	
	
}
