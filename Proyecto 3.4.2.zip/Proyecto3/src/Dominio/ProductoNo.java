package Dominio;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import Persistencia.ProductoNoDao;
import Persistencia.ProductoPeDao;

public class ProductoNo extends Producto {
private Oferta oferta;
private ProductoNoDao pronodao = new ProductoNoDao();


public ProductoNo(int id, String nombre, double precio, int unidades, Oferta oferta) {
	super(id, nombre, precio, unidades);
	this.oferta = oferta;
}

public ProductoNo () {
	
}
public Oferta getOferta() {
	return oferta;
}


public void setOferta(Oferta oferta) {
	this.oferta = oferta;
}

public Producto clone() {
	return new ProductoNo(this.getId(), 
			this.getNombre(), this.getPrecio(), this.getUnidades(), this.getOferta());
	}
	public Producto clone(int unidadesCompradas) {
		//se restan unidades compradas al objeto de la lista
		this.setUnidades(this.getUnidades()-unidadesCompradas);
		
		
		return new ProductoNo(this.getId(), this.getNombre(), this.getPrecio(),unidadesCompradas, this.getOferta());
		
		
	}
	public double calcularOferta() {
        double  Precio=this.getPrecio();
        int unidades= this.getUnidades();
        double resultado=0;
      
        if(this.getOferta().getIdOferta() == 11) {

        resultado=Precio*(unidades/2)+(Precio*(unidades%2));
     
        }



        if(this.getOferta().getIdOferta() == 12){
        {resultado=Precio*(unidades/3)*2+(Precio*(unidades%3));
   }
        }
        // error no pasa los valore de porcentaje y m�ximo
     
        if(this.getOferta().getIdOferta() == 3 ){
        	  int porcentaje = this.getOferta().getTantoPorCiento();
              int maximo = this.getOferta().getMaximo();
        	if (unidades <= maximo) {
        		resultado= unidades* Precio*(100- porcentaje)/100;
        	   
        	}else {resultado = maximo * Precio *(100- porcentaje)/100 + (unidades - maximo)* Precio;
        		
        	}
    
        }
            


        return resultado;
        }
	
		
	


public ArrayList <Producto> leerProductos () throws IOException{
	return pronodao.leerProductos();
	
}

public void escribirProductos(ArrayList <Producto> productos)throws IOException{
	pronodao.escribirProductos(productos);
}

@Override
public String toString() {
	return "ProductoNo [oferta=" + oferta + "]";
}



}
