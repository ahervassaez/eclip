package Dominio;
import java.util.*;

import Persistencia.EmpleadoNocturnoDao;

import java.io.FileNotFoundException;
import java.io.IOException;

public class EmpleadoNocturno extends Empleado {
private double plusproductividad;
private EmpleadoNocturnoDao empdao = new EmpleadoNocturnoDao();


public EmpleadoNocturno(int codigoAcceso, String nombreUsuario, String password, int nivel, String turno,
		double plusproductividad) {
	super(codigoAcceso, nombreUsuario, password, nivel, turno);
	this.plusproductividad = plusproductividad;
}

public EmpleadoNocturno() {
	
}

public double getPlusproductividad() {
	return plusproductividad;
}

public void setPlusproductividad(double plusproductividad) {
	this.plusproductividad = plusproductividad;
	
}
public ArrayList <Empleado> leerEmpleados () throws FileNotFoundException{
	return empdao.leerEmpleados();
	
}

public ArrayList <Empleado>escribirEmpleados(ArrayList <Empleado> empleados)throws IOException{
	return empdao.escribirEmpleados(empleados);
}

@Override
public void calcularProd( double precioT) {
	double productividad = 0;
	
	
	
	
	int nivel = this.getNivel();

if (nivel == 1) {
	productividad += 1+ (precioT* ((EmpleadoNocturno)this).getPlusproductividad()/100);
	if (precioT >= 200) {
		productividad = 2*( 1+ (precioT* ((EmpleadoNocturno)this).getPlusproductividad()/100));

} else if(nivel ==2 ) {
productividad += 2+ (precioT* ((EmpleadoNocturno)this).getPlusproductividad()/100);

}



} else {
productividad += 3- (3* ((EmpleadoNocturno)this).getPlusproductividad()/100);
}


this.setProductividad(productividad);
}
}







