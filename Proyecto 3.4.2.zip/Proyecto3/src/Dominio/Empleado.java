package Dominio;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
abstract public class Empleado {
	protected  int CodigoAcceso;
	protected String NombreUsuario;
	protected String password;
	private int nivel;
	private String turno;
	protected double productividad= 0;
	
	public Empleado(int codigoAcceso, String nombreUsuario, String password, int nivel, String turno) {

		CodigoAcceso = codigoAcceso;
		NombreUsuario = nombreUsuario;
		this.password = password;
		this.nivel = nivel;
		this.turno = turno;
	}
	public Empleado() {
       
	}

	public int getCodigoAcceso() {
		return CodigoAcceso;
	}

	public void setCodigoAcceso(int codigoAcceso) {
		CodigoAcceso = codigoAcceso;
	}

	public String getNombreUsuario() {
		return NombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		NombreUsuario = nombreUsuario;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getNivel() {
		return nivel;
	}

	public void setNivel(int nivel) {
		this.nivel = nivel;
	}

	public String getTurno() {
		return turno;
	}

	public void setTurno(String turno) {
		this.turno = turno;
	}
	
	 public double getProductividad() {
		return productividad;
	}
	public void setProductividad(double productividad) {
		this.productividad = productividad;
	}
	abstract public void calcularProd( double precioT) ;
		 
	
	
	abstract public ArrayList <Empleado> leerEmpleados() throws FileNotFoundException;
	abstract public ArrayList <Empleado> escribirEmpleados (ArrayList <Empleado> empleados) throws IOException;
}// fin de Empleado
