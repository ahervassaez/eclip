package Dominio;

import java.io.IOException;
import java.util.ArrayList;

import Persistencia.OfertaDao;

public class Oferta {
private String tipo;
private int idOferta;
private int tantoPorCiento;
private int maximo;
private OfertaDao ofedao = new OfertaDao();








public Oferta(String tipo, int idOferta, int tantoPorCiento, int maximo) {
	super();
	this.tipo = tipo;
	this.idOferta = idOferta;
	this.tantoPorCiento = tantoPorCiento;
	this.maximo = maximo;
} // tipo idOferta




public Oferta(String tipo, int idOferta) {
	super();
	this.tipo = tipo;
	this.idOferta = idOferta;
}




public Oferta() {
	
}







public String getTipo() {
	return tipo;
}




public void setTipo(String tipo) {
	this.tipo = tipo;
}




public int getIdOferta() {
	return idOferta;
}




public void setIdOferta(int idOferta) {
	this.idOferta = idOferta;
}




public int getTantoPorCiento() {
	return tantoPorCiento;
}




public void setTantoPorCiento(int tantoPorCiento) {
	this.tantoPorCiento = tantoPorCiento;
}




public int getMaximo() {
	return maximo;
}




public void setMaximo(int maximo) {
	this.maximo = maximo;
}




public ArrayList <Oferta> leerofertas() throws IOException{
	return ofedao.leerOfertas();
}

public ArrayList <Oferta> escribirOfertas(ArrayList<Oferta>ofertas)throws IOException{
	return ofedao.escribirOfertas(ofertas);
}




@Override
public String toString() {
	return "Oferta [tipo=" + tipo + "]";
}



}// fin de la clase ofertas




